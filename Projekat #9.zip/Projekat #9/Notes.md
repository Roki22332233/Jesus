- :root {
  --blue: #1e90ff;
  --white: #ffffff;
}

 body { background-color: var(--blue); }

 h2 { border-bottom: 2px solid var(--blue); }


- we need to add js animation while scrolling and custom scroll

- Eliasin sitesinde bunu dene. 

img yada body {
  background-image: url("photographer.jpg"); /* The image used */
  background-color: #cccccc; /* Used if the image is unavailable */
  height: 500px; /* You must set a specified height */
  background-position: center; /* Center the image */
  background-repeat: no-repeat; /* Do not repeat the image */
  background-size: cover; /* Resize the background image to cover the entire container */
}

- Change menu color to darker color.
- Add FIFA 22!